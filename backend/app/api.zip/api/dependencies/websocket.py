from fastapi import WebSocket


async def authenticate_websocket(
    websocket: WebSocket,
):
    """
    Placeholder for websocket authentication.

    Will be expanded when we build
    websocket_service.py.
    """

    return websocket