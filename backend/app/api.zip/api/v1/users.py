from fastapi import APIRouter, Depends, Query, status

from app.api.dependencies.auth import get_current_user
from app.models.user import User
from app.schemas.user import (
    UserResponse,
    UserUpdate,
    UserProfile,
    UserStatusUpdate,
    UserListResponse,
)
from app.services.user_service import (
    get_user_profile,
    update_user_profile,
    update_user_status,
    search_users,
    delete_account,
)

router = APIRouter(
    prefix="/users",
    tags=["Users"],
)


@router.get(
    "/me",
    response_model=UserResponse,
)
def get_me(
    current_user: User = Depends(get_current_user),
):
    """
    Return current authenticated user.
    """
    return current_user


@router.get(
    "/{user_id}",
    response_model=UserProfile,
)
def get_profile(
    user_id: int,
):
    """
    Get public profile of any user.
    """
    return get_user_profile(user_id)


@router.put(
    "/me",
    response_model=UserResponse,
)
def update_profile(
    data: UserUpdate,
    current_user: User = Depends(get_current_user),
):
    """
    Update profile.
    """
    return update_user_profile(
        current_user.id,
        data,
    )


@router.patch(
    "/me/status",
    response_model=UserResponse,
)
def update_status(
    data: UserStatusUpdate,
    current_user: User = Depends(get_current_user),
):
    """
    Update online status.
    """
    return update_user_status(
        current_user.id,
        data,
    )


@router.get(
    "/",
    response_model=UserListResponse,
)
def search(
    username: str = Query(..., min_length=1),
):
    """
    Search users by username.
    """
    return search_users(username)


@router.delete(
    "/me",
    status_code=status.HTTP_204_NO_CONTENT,
)
def delete_me(
    current_user: User = Depends(get_current_user),
):
    """
    Delete own account.
    """
    delete_account(current_user.id)

    return None