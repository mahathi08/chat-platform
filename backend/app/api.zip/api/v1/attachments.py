from fastapi import (
    APIRouter,
    Depends,
    File,
    UploadFile,
    status,
)

from app.api.dependencies.auth import get_current_user
from app.models.user import User
from app.schemas.attachment import (
    AttachmentResponse,
    AttachmentListResponse,
)
from app.services.attachment_service import (
    upload_attachment,
    get_attachment,
    get_user_attachments,
    delete_attachment,
)

router = APIRouter(
    prefix="/attachments",
    tags=["Attachments"],
)


@router.post(
    "/",
    response_model=AttachmentResponse,
    status_code=status.HTTP_201_CREATED,
)
async def upload(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
):
    """
    Upload an attachment.
    """
    return await upload_attachment(
        file=file,
        user_id=current_user.id,
    )


@router.get(
    "/",
    response_model=AttachmentListResponse,
)
def list_attachments(
    current_user: User = Depends(get_current_user),
):
    """
    List uploaded attachments.
    """
    return get_user_attachments(
        current_user.id,
    )


@router.get(
    "/{attachment_id}",
    response_model=AttachmentResponse,
)
def get(
    attachment_id: int,
    current_user: User = Depends(get_current_user),
):
    """
    Get attachment metadata.
    """
    return get_attachment(
        attachment_id,
        current_user.id,
    )


@router.delete(
    "/{attachment_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
def delete(
    attachment_id: int,
    current_user: User = Depends(get_current_user),
):
    """
    Delete attachment.
    """
    delete_attachment(
        attachment_id,
        current_user.id,
    )

    return None