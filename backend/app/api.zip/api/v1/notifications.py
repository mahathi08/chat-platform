from fastapi import APIRouter, Depends, Query, status

from app.api.dependencies.auth import get_current_user
from app.models.user import User
from app.schemas.notification import (
    NotificationResponse,
    NotificationListResponse,
)
from app.services.notification_service import (
    get_notifications,
    mark_as_read,
    mark_all_as_read,
    delete_notification,
)

router = APIRouter(
    prefix="/notifications",
    tags=["Notifications"],
)


@router.get(
    "/",
    response_model=NotificationListResponse,
)
def list_notifications(
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    current_user: User = Depends(get_current_user),
):
    """
    Get current user's notifications.
    """
    return get_notifications(
        current_user.id,
        page,
        page_size,
    )


@router.patch(
    "/{notification_id}/read",
    response_model=NotificationResponse,
)
def read_notification(
    notification_id: int,
    current_user: User = Depends(get_current_user),
):
    """
    Mark notification as read.
    """
    return mark_as_read(
        notification_id,
        current_user.id,
    )


@router.patch(
    "/read-all",
    status_code=status.HTTP_200_OK,
)
def read_all(
    current_user: User = Depends(get_current_user),
):
    """
    Mark all notifications as read.
    """
    return mark_all_as_read(current_user.id)


@router.delete(
    "/{notification_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
def delete(
    notification_id: int,
    current_user: User = Depends(get_current_user),
):
    """
    Delete a notification.
    """
    delete_notification(
        notification_id,
        current_user.id,
    )

    return None