from fastapi import APIRouter, Depends, Query, status

from app.api.dependencies.auth import get_current_user
from app.models.user import User
from app.schemas.message import (
    MessageCreate,
    MessageUpdate,
    MessageResponse,
    MessageListResponse,
)
from app.services.message_service import (
    send_message,
    get_channel_messages,
    get_message,
    update_message,
    delete_message,
    pin_message,
    unpin_message,
)

router = APIRouter(
    prefix="/messages",
    tags=["Messages"],
)


@router.post(
    "/channels/{channel_id}",
    response_model=MessageResponse,
    status_code=status.HTTP_201_CREATED,
)
def create(
    channel_id: int,
    data: MessageCreate,
    current_user: User = Depends(get_current_user),
):
    """
    Send a message to a channel.
    """
    return send_message(
        channel_id=channel_id,
        user_id=current_user.id,
        data=data,
    )


@router.get(
    "/channels/{channel_id}",
    response_model=MessageListResponse,
)
def list_messages(
    channel_id: int,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    current_user: User = Depends(get_current_user),
):
    """
    Get paginated messages.
    """
    return get_channel_messages(
        channel_id=channel_id,
        page=page,
        page_size=page_size,
    )


@router.get(
    "/{message_id}",
    response_model=MessageResponse,
)
def get(
    message_id: int,
    current_user: User = Depends(get_current_user),
):
    """
    Get a single message.
    """
    return get_message(message_id)


@router.patch(
    "/{message_id}",
    response_model=MessageResponse,
)
def edit(
    message_id: int,
    data: MessageUpdate,
    current_user: User = Depends(get_current_user),
):
    """
    Edit a message.
    """
    return update_message(
        message_id=message_id,
        user_id=current_user.id,
        data=data,
    )


@router.delete(
    "/{message_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
def delete(
    message_id: int,
    current_user: User = Depends(get_current_user),
):
    """
    Delete a message.
    """
    delete_message(
        message_id=message_id,
        user_id=current_user.id,
    )

    return None


@router.patch(
    "/{message_id}/pin",
    response_model=MessageResponse,
)
def pin(
    message_id: int,
    current_user: User = Depends(get_current_user),
):
    """
    Pin a message.
    """
    return pin_message(
        message_id,
        current_user.id,
    )


@router.patch(
    "/{message_id}/unpin",
    response_model=MessageResponse,
)
def unpin(
    message_id: int,
    current_user: User = Depends(get_current_user),
):
    """
    Unpin a message.
    """
    return unpin_message(
        message_id,
        current_user.id,
    )