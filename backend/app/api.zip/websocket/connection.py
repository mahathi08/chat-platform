from fastapi import (
    WebSocket,
    WebSocketDisconnect,
)

from app.api.dependencies.websocket import (
    authenticate_websocket,
)

from app.websocket.manager import (
    manager,
)

from app.websocket.events import (
    handle_event,
)

from app.websocket.presence import (
    set_online,
    set_offline,
    update_last_seen,
)


async def websocket_connection(
    websocket: WebSocket,
):
    user = await authenticate_websocket(
        websocket,
    )

    await manager.connect(
        websocket,
        user.id,
    )

    set_online(
        user.id,
    )

    try:
        while True:
            data = await websocket.receive_json()

            await handle_event(
                websocket,
                user,
                data,
            )

    except WebSocketDisconnect:
        pass

    finally:
        await manager.disconnect(
            user.id,
        )

        set_offline(
            user.id,
        )

        update_last_seen(
            user.id,
        )