from collections import defaultdict

from fastapi import WebSocket


class ConnectionManager:
    """
    Manages all active websocket connections.
    """

    def __init__(self):

        # user_id -> websocket
        self.active_connections: dict[
            int,
            WebSocket,
        ] = {}

        # channel_id -> set(user_ids)
        self.channel_rooms: dict[
            int,
            set[int],
        ] = defaultdict(set)

        # server_id -> set(user_ids)
        self.server_rooms: dict[
            int,
            set[int],
        ] = defaultdict(set)

        # conversation_id -> set(user_ids)
        self.dm_rooms: dict[
            int,
            set[int],
        ] = defaultdict(set)

    async def connect(
        self,
        websocket: WebSocket,
        user_id: int,
    ):

        await websocket.accept()

        self.active_connections[
            user_id
        ] = websocket

    async def disconnect(
        self,
        user_id: int,
    ):

        self.active_connections.pop(
            user_id,
            None,
        )

        self.remove_user_from_all_rooms(
            user_id,
        )

    def is_connected(
        self,
        user_id: int,
    ) -> bool:

        return (
            user_id
            in self.active_connections
        )

    def get_connection(
        self,
        user_id: int,
    ) -> WebSocket | None:

        return self.active_connections.get(
            user_id,
        )

    async def send_personal_message(
        self,
        user_id: int,
        data: dict,
    ):

        websocket = self.get_connection(
            user_id,
        )

        if websocket:

            await websocket.send_json(
                data,
            )

    async def broadcast(
        self,
        data: dict,
    ):

        disconnected = []

        for (
            user_id,
            websocket,
        ) in self.active_connections.items():

            try:

                await websocket.send_json(
                    data,
                )

            except Exception:

                disconnected.append(
                    user_id,
                )

        for user_id in disconnected:

            await self.disconnect(
                user_id,
            )


    async def broadcast_to_server(
        self,
        server_id: int,
        data: dict,
    ):

        users = self.server_rooms.get(
            server_id,
            set(),
        )

        await self.broadcast_to_users(
            users,
            data,
        )
        
    async def broadcast_to_users(
        self,
        users: set[int],
        data: dict,
    ):

        for user_id in users:

            await self.send_personal_message(
                user_id,
                data,
            )

    async def broadcast_to_conversation(
        self,
        conversation_id: int,
        data: dict,
    ):

        users = self.dm_rooms.get(
            conversation_id,
            set(),
        )

        await self.broadcast_to_users(
            users,
            data,
        )

    def remove_user_from_all_rooms(
        self,
        user_id: int,
    ):

        for room in (
            self.channel_rooms.values()
        ):

            room.discard(user_id)

        for room in (
            self.server_rooms.values()
        ):

            room.discard(user_id)

        for room in (
            self.dm_rooms.values()
        ):

            room.discard(user_id)


manager = ConnectionManager()