from datetime import datetime

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.models.message import Message
from app.models.channel import Channel
from app.models.user import User

from app.schemas.message import (
    MessageCreate,
    MessageUpdate,
    MessageListResponse,
)
def get_message(
    db: Session,
    message_id: int,
) -> Message:

    message = (
        db.query(Message)
        .filter(
            Message.id == message_id
        )
        .first()
    )

    if message is None:

        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Message not found.",
        )

    return message


def get_channel(
    db: Session,
    channel_id: int,
) -> Channel:

    channel = (
        db.query(Channel)
        .filter(
            Channel.id == channel_id
        )
        .first()
    )

    if channel is None:

        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Channel not found.",
        )

    return channel
def send_message(
    db: Session,
    channel_id: int,
    user_id: int,
    data: MessageCreate,
) -> Message:

    get_channel(
        db,
        channel_id,
    )

    message = Message(
        channel_id=channel_id,
        author_id=user_id,
        content=data.content,
    )

    db.add(message)

    db.commit()

    db.refresh(message)

    return message

def get_message_by_id(
    db: Session,
    message_id: int,
) -> Message:

    return get_message(
        db,
        message_id,
    )

def get_channel_messages(
    db: Session,
    channel_id: int,
    page: int,
    page_size: int,
) -> MessageListResponse:

    get_channel(
        db,
        channel_id,
    )

    messages = (
        db.query(Message)
        .filter(
            Message.channel_id == channel_id
        )
        .order_by(
            Message.created_at.desc()
        )
        .offset(
            (page - 1) * page_size
        )
        .limit(page_size)
        .all()
    )

    return MessageListResponse(
        messages=list(reversed(messages))
    )

def update_message(
    db: Session,
    message_id: int,
    user_id: int,
    data: MessageUpdate,
) -> Message:

    message = get_message(
        db,
        message_id,
    )

    if message.author_id != user_id:

        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cannot edit another user's message.",
        )

    message.content = data.content

    message.edited_at = datetime.utcnow()

    db.commit()

    db.refresh(message)

    return message


def update_message(
    db: Session,
    message_id: int,
    user_id: int,
    data: MessageUpdate,
) -> Message:

    message = get_message(
        db,
        message_id,
    )

    if message.author_id != user_id:

        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cannot edit another user's message.",
        )

    message.content = data.content

    message.edited_at = datetime.utcnow()

    db.commit()

    db.refresh(message)

    return message

def delete_message(
    db: Session,
    message_id: int,
    user_id: int,
):

    message = get_message(
        db,
        message_id,
    )

    if message.author_id != user_id:

        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cannot delete another user's message.",
        )

    db.delete(message)

    db.commit()


def reply_to_message(
    db: Session,
    channel_id: int,
    parent_message_id: int,
    user_id: int,
    data: MessageCreate,
) -> Message:

    get_channel(
        db,
        channel_id,
    )

    parent = get_message(
        db,
        parent_message_id,
    )

    message = Message(
        channel_id=channel_id,
        author_id=user_id,
        content=data.content,
        reply_to_id=parent.id,
    )

    db.add(message)

    db.commit()

    db.refresh(message)

    return message

def pin_message(
    db: Session,
    message_id: int,
    user_id: int,
):

    message = get_message(
        db,
        message_id,
    )

    message.is_pinned = True

    db.commit()

    db.refresh(message)

    return message

def unpin_message(
    db: Session,
    message_id: int,
    user_id: int,
):

    message = get_message(
        db,
        message_id,
    )

    message.is_pinned = False

    db.commit()

    db.refresh(message)

    return message


def search_messages(
    db: Session,
    channel_id: int,
    query: str,
):

    return (
        db.query(Message)
        .filter(
            Message.channel_id == channel_id,
            Message.content.ilike(
                f"%{query}%"
            ),
        )
        .order_by(
            Message.created_at.desc()
        )
        .all()
    )

def get_pinned_messages(
    db: Session,
    channel_id: int,
):

    return (
        db.query(Message)
        .filter(
            Message.channel_id == channel_id,
            Message.is_pinned == True,
        )
        .order_by(
            Message.created_at.desc()
        )
        .all()
    )

