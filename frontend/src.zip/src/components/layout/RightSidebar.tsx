export default function RightSidebar() {
    return (
        <aside className="w-64 bg-[#2b2d31] border-l border-[#1e1f22]">

            <div className="p-4 font-semibold">
                Members
            </div>

            <div className="p-4 space-y-3">

                <div className="flex items-center gap-3">

                    <div className="h-9 w-9 rounded-full bg-green-600"></div>

                    <span>User 1</span>

                </div>

                <div className="flex items-center gap-3">

                    <div className="h-9 w-9 rounded-full bg-gray-500"></div>

                    <span>User 2</span>

                </div>

            </div>

        </aside>
    );
}