import { Outlet } from "react-router-dom";

import Sidebar from "./Sidebar";
import ServerSidebar from "./ServerSidebar";
import RightSidebar from "./RightSidebar";
import ChatHeader from "./ChatHeader";

export default function DashboardLayout() {
    return (
        <div className="h-screen w-screen flex bg-[#313338] text-white overflow-hidden">

            {/* Server Icons */}
            <ServerSidebar />

            {/* Channels */}
            <Sidebar />

            {/* Main Area */}
            <div className="flex-1 flex flex-col">

                <ChatHeader />

                <div className="flex-1 overflow-hidden">
                    <Outlet />
                </div>

            </div>

            {/* Members / Profile */}
            <RightSidebar />

        </div>
    );
}