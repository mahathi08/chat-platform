import { Link } from "react-router-dom";

export default function ServerSidebar() {
    return (
        <aside className="w-20 bg-[#1e1f22] flex flex-col items-center py-4 gap-4">

            <Link
                to="/app"
                className="h-12 w-12 rounded-full bg-blue-600 flex items-center justify-center text-xl font-bold hover:rounded-2xl transition-all"
            >
                C
            </Link>

            <div className="w-10 border-t border-gray-600"></div>

            <button
                className="h-12 w-12 rounded-full bg-[#313338] hover:bg-green-600 transition-all"
            >
                +
            </button>

        </aside>
    );
}