export default function Sidebar() {
    return (
        <aside className="w-64 bg-[#2b2d31] flex flex-col">

            <div className="h-14 border-b border-[#1e1f22] flex items-center px-4 font-semibold">
                Server Name
            </div>

            <div className="flex-1 overflow-y-auto p-2">

                <div className="text-xs uppercase text-gray-400 px-2 mb-2">
                    TEXT CHANNELS
                </div>

                <button className="w-full text-left px-2 py-2 rounded hover:bg-[#404249]">
                    # general
                </button>

                <button className="w-full text-left px-2 py-2 rounded hover:bg-[#404249]">
                    # announcements
                </button>

            </div>

        </aside>
    );
}