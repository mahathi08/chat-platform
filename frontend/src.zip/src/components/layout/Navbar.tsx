import { Link } from "react-router-dom";

export default function Navbar() {
    return (
        <nav className="h-14 bg-[#1e1f22] flex items-center justify-between px-6">

            <h1 className="text-lg font-bold text-white">
                Chat Platform
            </h1>

            <div className="flex gap-5">

                <Link to="/app">
                    Home
                </Link>

                <Link to="/app/explore">
                    Explore
                </Link>

                <Link to="/app/settings/profile">
                    Profile
                </Link>

            </div>

        </nav>
    );
}