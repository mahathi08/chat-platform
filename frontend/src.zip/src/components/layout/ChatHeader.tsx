export default function ChatHeader() {
    return (
        <header className="h-14 border-b border-[#1e1f22] flex items-center justify-between px-6">

            <div className="flex items-center gap-2">

                <span className="text-gray-400 text-xl">
                    #
                </span>

                <span className="font-semibold">
                    general
                </span>

            </div>

            <div className="flex gap-4">

                <button>🔍</button>

                <button>📌</button>

                <button>👥</button>

            </div>

        </header>
    );
}