import { ButtonHTMLAttributes, ReactNode } from "react";

interface ButtonProps
    extends ButtonHTMLAttributes<HTMLButtonElement> {
    children: ReactNode;
    loading?: boolean;
    variant?: "primary" | "secondary" | "danger";
}

export default function Button({
    children,
    loading = false,
    variant = "primary",
    className = "",
    disabled,
    ...props
}: ButtonProps) {
    const base =
        "px-4 py-2 rounded-lg font-medium transition-colors duration-200";

    const variants = {
        primary:
            "bg-blue-600 text-white hover:bg-blue-700",
        secondary:
            "bg-gray-200 text-gray-900 hover:bg-gray-300",
        danger:
            "bg-red-600 text-white hover:bg-red-700",
    };

    return (
        <button
            {...props}
            disabled={disabled || loading}
            className={`${base} ${variants[variant]} ${className}`}
        >
            {loading ? "Loading..." : children}
        </button>
    );
}