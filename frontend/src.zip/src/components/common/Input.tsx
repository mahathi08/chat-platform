import { InputHTMLAttributes } from "react";

interface InputProps
    extends InputHTMLAttributes<HTMLInputElement> {
    label?: string;
    error?: string;
}

export default function Input({
    label,
    error,
    className = "",
    ...props
}: InputProps) {
    return (
        <div className="flex flex-col gap-1 w-full">
            {label && (
                <label className="text-sm font-medium">
                    {label}
                </label>
            )}

            <input
                {...props}
                className={`border rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 ${className}`}
            />

            {error && (
                <span className="text-red-500 text-sm">
                    {error}
                </span>
            )}
        </div>
    );
}