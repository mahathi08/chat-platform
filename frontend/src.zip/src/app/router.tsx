import { createBrowserRouter, Navigate } from "react-router-dom";

import DashboardLayout from "../components/layout/DashboardLayout";

import Login from "../pages/auth/Login";
import Register from "../pages/auth/Register";
import ForgotPassword from "../pages/auth/ForgotPassword";

import Dashboard from "../pages/dashboard/Dashboard";
import Home from "../pages/dashboard/Home";
import Explore from "../pages/dashboard/Explore";

import ServerPage from "../pages/servers/ServerPage";
import CreateServer from "../pages/servers/CreateServer";
import InvitePage from "../pages/servers/InvitePage";
import MembersPage from "../pages/servers/MembersPage";

import ChannelPage from "../pages/channels/ChannelPage";
import CreateChannel from "../pages/channels/CreateChannel";

import DirectMessage from "../pages/dms/DirectMessage";

import Notifications from "../pages/notifications/Notifications";

import Profile from "../pages/settings/Profile";
import Account from "../pages/settings/Account";
import Appearance from "../pages/settings/Appearance";

import NotFound from "../pages/NotFound";

export const router = createBrowserRouter([
    {
        path: "/",
        element: <Navigate to="/login" replace />,
    },

    {
        path: "/login",
        element: <Login />,
    },

    {
        path: "/register",
        element: <Register />,
    },

    {
        path: "/forgot-password",
        element: <ForgotPassword />,
    },

    {
        path: "/app",
        element: <DashboardLayout />,
        children: [
            {
                index: true,
                element: <Dashboard />,
            },

            {
                path: "home",
                element: <Home />,
            },

            {
                path: "explore",
                element: <Explore />,
            },

            {
                path: "servers/new",
                element: <CreateServer />,
            },

            {
                path: "servers/:serverId",
                element: <ServerPage />,
            },

            {
                path: "servers/:serverId/invite",
                element: <InvitePage />,
            },

            {
                path: "servers/:serverId/members",
                element: <MembersPage />,
            },

            {
                path: "channels/new",
                element: <CreateChannel />,
            },

            {
                path: "channels/:channelId",
                element: <ChannelPage />,
            },

            {
                path: "dm/:userId",
                element: <DirectMessage />,
            },

            {
                path: "notifications",
                element: <Notifications />,
            },

            {
                path: "settings/profile",
                element: <Profile />,
            },

            {
                path: "settings/account",
                element: <Account />,
            },

            {
                path: "settings/appearance",
                element: <Appearance />,
            },
        ],
    },

    {
        path: "*",
        element: <NotFound />,
    },
]);