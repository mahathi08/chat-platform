import { UserProfile } from "./user";

export interface ServerCreate {
    name: string;
    description?: string;
    icon_url?: string;
}

export interface ServerUpdate {
    name?: string;
    description?: string;
    icon_url?: string;
}

export interface ServerResponse {
    id: number;
    name: string;
    description: string | null;
    icon_url: string | null;
    owner_id: number;
    created_at: string;
    updated_at: string;
}

export interface ServerMemberResponse {
    id: number;
    role: string;
    joined_at: string;
    user: UserProfile;
}

export interface ServerListResponse {
    servers: ServerResponse[];
}