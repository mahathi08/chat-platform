export type MessageType =
    | "TEXT"
    | "SYSTEM"
    | "IMAGE"
    | "FILE";

export interface MessageCreate {
    content: string;
    reply_to_id?: number;
}

export interface MessageUpdate {
    content: string;
}

export interface MessageResponse {
    id: number;
    channel_id: number;
    author_id: number;
    content: string;
    message_type: MessageType;
    reply_to_id: number | null;
    is_edited: boolean;
    is_deleted: boolean;
    is_pinned: boolean;
    created_at: string;
    edited_at: string | null;
}

export interface MessageListResponse {
    messages: MessageResponse[];
}