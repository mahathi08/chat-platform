import api from "./api";

export interface RegisterData {
    username: string;
    email: string;
    password: string;
}

export interface LoginData {
    email: string;
    password: string;
}

export interface AuthResponse {
    access_token: string;
    token_type: string;
}

export interface User {
    id: string;
    username: string;
    email: string;
    avatar_url?: string;
}

class AuthService {
    async register(data: RegisterData) {
        const response = await api.post("/auth/register", data);
        return response.data;
    }

    async login(data: LoginData): Promise<AuthResponse> {
        const response = await api.post("/auth/login", data);

        const token = response.data.access_token;

        if (token) {
            localStorage.setItem("access_token", token);
        }

        return response.data;
    }

    async getCurrentUser(): Promise<User> {
        const response = await api.get("/auth/me");

        localStorage.setItem(
            "user",
            JSON.stringify(response.data)
        );

        return response.data;
    }

    logout() {
        localStorage.removeItem("access_token");
        localStorage.removeItem("user");
    }

    isAuthenticated() {
        return !!localStorage.getItem("access_token");
    }

    getStoredUser(): User | null {
        const user = localStorage.getItem("user");

        if (!user) return null;

        return JSON.parse(user);
    }
}

export default new AuthService();