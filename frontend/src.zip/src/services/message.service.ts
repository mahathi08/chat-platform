import api from "./api";

export interface MessageCreate {
    channel_id: number;
    content: string;
    attachments?: string[];
}

export interface MessageUpdate {
    content: string;
}

class MessageService {
    async getChannelMessages(
        channelId: number,
        page: number = 1,
        limit: number = 50
    ) {
        const response = await api.get(
            `/channels/${channelId}/messages`,
            {
                params: {
                    page,
                    limit,
                },
            }
        );

        return response.data;
    }

    async sendMessage(data: MessageCreate) {
        const response = await api.post(
            "/messages",
            data
        );

        return response.data;
    }

    async getMessage(messageId: number) {
        const response = await api.get(
            `/messages/${messageId}`
        );

        return response.data;
    }

    async editMessage(
        messageId: number,
        data: MessageUpdate
    ) {
        const response = await api.put(
            `/messages/${messageId}`,
            data
        );

        return response.data;
    }

    async deleteMessage(messageId: number) {
        await api.delete(
            `/messages/${messageId}`
        );
    }

    async pinMessage(messageId: number) {
        const response = await api.post(
            `/messages/${messageId}/pin`
        );

        return response.data;
    }

    async unpinMessage(messageId: number) {
        const response = await api.post(
            `/messages/${messageId}/unpin`
        );

        return response.data;
    }

    async addReaction(
        messageId: number,
        emoji: string
    ) {
        const response = await api.post(
            `/messages/${messageId}/reactions`,
            {
                emoji,
            }
        );

        return response.data;
    }

    async removeReaction(
        messageId: number,
        emoji: string
    ) {
        const response = await api.delete(
            `/messages/${messageId}/reactions`,
            {
                data: {
                    emoji,
                },
            }
        );

        return response.data;
    }
}

export default new MessageService();