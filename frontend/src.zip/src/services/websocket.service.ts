type EventCallback = (data: any) => void;

class WebSocketService {
    private socket: WebSocket | null = null;

    private listeners: Map<string, EventCallback[]> = new Map();

    private reconnectAttempts = 0;

    private readonly maxReconnectAttempts = 10;

    private readonly reconnectDelay = 3000;

    connect(token: string) {
        if (
            this.socket &&
            this.socket.readyState === WebSocket.OPEN
        ) {
            return;
        }

        const base =
            import.meta.env.VITE_WS_URL ??
            "ws://localhost:8000/api/v1/ws";

        this.socket = new WebSocket(
            `${base}?token=${token}`
        );

        this.socket.onopen = () => {
            console.log("WebSocket Connected");
            this.reconnectAttempts = 0;
            this.emit("connected", {});
        };

        this.socket.onmessage = (event) => {
            try {
                const message = JSON.parse(event.data);

                this.emit(
                    message.type,
                    message.payload
                );
            } catch (err) {
                console.error(err);
            }
        };

        this.socket.onclose = () => {
            console.log("WebSocket Closed");

            this.emit("disconnected", {});

            if (
                this.reconnectAttempts <
                this.maxReconnectAttempts
            ) {
                this.reconnectAttempts++;

                setTimeout(() => {
                    this.connect(token);
                }, this.reconnectDelay);
            }
        };

        this.socket.onerror = (error) => {
            console.error(error);
        };
    }

    disconnect() {
        if (this.socket) {
            this.socket.close();
            this.socket = null;
        }
    }

    send(type: string, payload: any) {
        if (
            !this.socket ||
            this.socket.readyState !== WebSocket.OPEN
        ) {
            return;
        }

        this.socket.send(
            JSON.stringify({
                type,
                payload,
            })
        );
    }

    on(
        event: string,
        callback: EventCallback
    ) {
        const callbacks =
            this.listeners.get(event) ?? [];

        callbacks.push(callback);

        this.listeners.set(event, callbacks);
    }

    off(
        event: string,
        callback: EventCallback
    ) {
        const callbacks =
            this.listeners.get(event);

        if (!callbacks) return;

        this.listeners.set(
            event,
            callbacks.filter(
                (cb) => cb !== callback
            )
        );
    }

    private emit(
        event: string,
        payload: any
    ) {
        const callbacks =
            this.listeners.get(event);

        if (!callbacks) return;

        callbacks.forEach((cb) => cb(payload));
    }

    sendChatMessage(
        channelId: number,
        content: string
    ) {
        this.send("chat_message", {
            channel_id: channelId,
            content,
        });
    }

    sendTyping(
        channelId: number
    ) {
        this.send("typing", {
            channel_id: channelId,
        });
    }

    joinChannel(
        channelId: number
    ) {
        this.send("join_channel", {
            channel_id: channelId,
        });
    }

    leaveChannel(
        channelId: number
    ) {
        this.send("leave_channel", {
            channel_id: channelId,
        });
    }
}

export default new WebSocketService();