import {
    createContext,
    useContext,
    useEffect,
    useState,
    ReactNode,
} from "react";

import websocketService from "../services/websocket.service";
import { useAuth } from "./AuthContext";

interface SocketContextType {
    connected: boolean;

    sendMessage: (
        channelId: number,
        content: string
    ) => void;

    sendTyping: (
        channelId: number
    ) => void;

    joinChannel: (
        channelId: number
    ) => void;

    leaveChannel: (
        channelId: number
    ) => void;

    on: (
        event: string,
        callback: (data: any) => void
    ) => void;

    off: (
        event: string,
        callback: (data: any) => void
    ) => void;
}

const SocketContext =
    createContext<SocketContextType>(
        {} as SocketContextType
    );

interface Props {
    children: ReactNode;
}

export function SocketProvider({
    children,
}: Props) {
    const { authenticated } = useAuth();

    const [connected, setConnected] =
        useState(false);

    useEffect(() => {
        if (!authenticated) return;

        const token =
            localStorage.getItem(
                "access_token"
            );

        if (!token) return;

        websocketService.connect(token);

        const handleConnect = () =>
            setConnected(true);

        const handleDisconnect = () =>
            setConnected(false);

        websocketService.on(
            "connected",
            handleConnect
        );

        websocketService.on(
            "disconnected",
            handleDisconnect
        );

        return () => {
            websocketService.off(
                "connected",
                handleConnect
            );

            websocketService.off(
                "disconnected",
                handleDisconnect
            );

            websocketService.disconnect();
        };
    }, [authenticated]);

    return (
        <SocketContext.Provider
            value={{
                connected,

                sendMessage:
                    websocketService.sendChatMessage.bind(
                        websocketService
                    ),

                sendTyping:
                    websocketService.sendTyping.bind(
                        websocketService
                    ),

                joinChannel:
                    websocketService.joinChannel.bind(
                        websocketService
                    ),

                leaveChannel:
                    websocketService.leaveChannel.bind(
                        websocketService
                    ),

                on: websocketService.on.bind(
                    websocketService
                ),

                off: websocketService.off.bind(
                    websocketService
                ),
            }}
        >
            {children}
        </SocketContext.Provider>
    );
}

export function useSocket() {
    return useContext(SocketContext);
}