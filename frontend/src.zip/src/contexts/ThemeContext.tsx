import {
    createContext,
    ReactNode,
    useContext,
    useEffect,
    useState,
} from "react";

export type Theme = "light" | "dark";

interface ThemeContextType {
    theme: Theme;
    toggleTheme: () => void;
    setTheme: (theme: Theme) => void;
}

const ThemeContext = createContext<ThemeContextType>(
    {} as ThemeContextType
);

interface Props {
    children: ReactNode;
}

export function ThemeProvider({ children }: Props) {
    const [theme, setThemeState] = useState<Theme>(() => {
        const stored = localStorage.getItem("theme");

        if (stored === "light" || stored === "dark") {
            return stored;
        }

        return window.matchMedia(
            "(prefers-color-scheme: dark)"
        ).matches
            ? "dark"
            : "light";
    });

    useEffect(() => {
        document.documentElement.setAttribute(
            "data-theme",
            theme
        );

        localStorage.setItem("theme", theme);
    }, [theme]);

    function setTheme(theme: Theme) {
        setThemeState(theme);
    }

    function toggleTheme() {
        setThemeState((prev) =>
            prev === "dark" ? "light" : "dark"
        );
    }

    return (
        <ThemeContext.Provider
            value={{
                theme,
                toggleTheme,
                setTheme,
            }}
        >
            {children}
        </ThemeContext.Provider>
    );
}

export function useTheme() {
    return useContext(ThemeContext);
}