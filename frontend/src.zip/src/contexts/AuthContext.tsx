import {
    createContext,
    useContext,
    useEffect,
    useState,
    ReactNode,
} from "react";

import AuthService, {
    LoginData,
    RegisterData,
    User,
} from "../services/auth.service";

interface AuthContextType {
    user: User | null;
    loading: boolean;
    authenticated: boolean;

    login: (data: LoginData) => Promise<void>;
    register: (data: RegisterData) => Promise<void>;
    logout: () => void;
    refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>(
    {} as AuthContextType
);

interface Props {
    children: ReactNode;
}

export function AuthProvider({ children }: Props) {
    const [user, setUser] = useState<User | null>(null);

    const [loading, setLoading] = useState(true);

    useEffect(() => {
        initialize();
    }, []);

    async function initialize() {
        try {
            if (!AuthService.isAuthenticated()) {
                setLoading(false);
                return;
            }

            const currentUser =
                await AuthService.getCurrentUser();

            setUser(currentUser);
        } catch {
            AuthService.logout();
            setUser(null);
        } finally {
            setLoading(false);
        }
    }

    async function login(data: LoginData) {
        await AuthService.login(data);

        const currentUser =
            await AuthService.getCurrentUser();

        setUser(currentUser);
    }

    async function register(data: RegisterData) {
        await AuthService.register(data);
    }

    function logout() {
        AuthService.logout();
        setUser(null);
    }

    async function refreshUser() {
        const currentUser =
            await AuthService.getCurrentUser();

        setUser(currentUser);
    }

    return (
        <AuthContext.Provider
            value={{
                user,
                loading,
                authenticated: !!user,
                login,
                register,
                logout,
                refreshUser,
            }}
        >
            {children}
        </AuthContext.Provider>
    );
}

export function useAuth() {
    return useContext(AuthContext);
}